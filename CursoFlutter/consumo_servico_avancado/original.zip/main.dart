import 'package:consumo_servico_avancado/Home.dart';
import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
  home: Home(),
));
