import 'package:flutter/material.dart';
import 'package:mascaracampos/Home.dart';

void main() => runApp(MaterialApp(
  title: "Mascaras e Validações",
  home: Home(),
  debugShowCheckedModeBanner: false,
));
