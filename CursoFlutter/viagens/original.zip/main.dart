import 'package:flutter/material.dart';
import 'SplashScreen.dart';

void main() => runApp(MaterialApp(
  title: "Minhas viagens",
  home: SplashScreen(),
  debugShowCheckedModeBanner: false,
));
