
class StatusRequisicao {

  static final String AGUARDANDO = "aguardando";
  static final String A_CAMINHO = "a_caminho";
  static final String VIAGEM = "viagem";
  static final String FINALIZADA = "finalizada";

}