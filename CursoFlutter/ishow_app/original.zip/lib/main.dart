import 'package:flutter/material.dart';
import 'package:ishowapp/Login.dart';

void main() => runApp(
  MaterialApp(
    home: Login(),
    debugShowCheckedModeBanner: false,
  )
);

