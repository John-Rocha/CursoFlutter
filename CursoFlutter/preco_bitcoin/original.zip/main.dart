import 'package:flutter/material.dart';
import 'package:preco_bitcoin/Home.dart';

void main() => runApp(
  MaterialApp(
    home: Home(),
    debugShowCheckedModeBanner: false,
  )
);

